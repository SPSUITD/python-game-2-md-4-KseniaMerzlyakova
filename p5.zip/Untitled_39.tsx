<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Untitled_39" tilewidth="128" tileheight="128" tilecount="135" columns="15">
 <image source="Untitled_39.png" width="1998" height="1198"/>
</tileset>
