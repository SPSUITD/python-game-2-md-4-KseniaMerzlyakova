<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="we1" tilewidth="128" tileheight="128" tilecount="4" columns="2">
 <image source="we1.png" width="315" height="315"/>
 <tile id="0">
  <properties>
   <property name="points" type="object" value="10"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="points" type="object" value="10"/>
  </properties>
 </tile>
</tileset>
