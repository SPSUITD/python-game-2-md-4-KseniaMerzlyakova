<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Ресурс 6@3x" tilewidth="128" tileheight="128" tilecount="4" columns="2">
 <image source="Ресурс 6@3x.png" trans="ff00ff" width="315" height="315"/>
</tileset>
