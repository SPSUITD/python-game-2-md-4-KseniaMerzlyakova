<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="bg" tilewidth="128" tileheight="128" tilecount="170" columns="17">
 <image source="bg.png" width="2282" height="1368"/>
</tileset>
