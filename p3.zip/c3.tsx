<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="c3" tilewidth="128" tileheight="128" tilecount="1" columns="1">
 <image source="c3.png" width="128" height="128"/>
</tileset>
