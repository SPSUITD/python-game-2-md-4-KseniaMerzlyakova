<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="bg2" tilewidth="128" tileheight="128" tilecount="2" columns="2">
 <image source="bg2.png" width="320" height="192"/>
</tileset>
